$(document).ready(function(){
	showDefaultDivs();
});

function showDefaultDivs(){
	$("#contentSelectorAdoptContent").show();
	$(".contentSelector").on("click", function () {
		$(".contentSelector").removeClass("clicked");
		$(this).addClass("clicked");
		var div = $(this).children("span").html().replace(/ /g,'');
		$(".contentSelectorContent").hide();
		$("#contentSelector"+div+"Content").show();
	});
}